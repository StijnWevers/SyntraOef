import { Application } from "https://unpkg.com/@splinetool/runtime@0.9.117/build/runtime.js";

const canvas = document.getElementById("canvas3d");
const app = new Application(canvas);
app.load("https://prod.spline.design/6ZQ5iT3IwGfD7GsZ/scene.splinecode");
